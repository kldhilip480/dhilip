package com.example.demo.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.EmployeeResponseDto;
import com.example.demo.dto.EmployeeSalaryDto;
import com.example.demo.entity.Employee;
import com.example.demo.exception.UserDefinedException;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;


@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;

	private static final Logger log = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	
	@Override
	public String saveEmployee(List<EmployeeDto> employeeDto) {
		employeeDto.stream().filter(employee -> !(employee.getName().isEmpty()) && employee.getAge() > 18)
				.collect(Collectors.toList());
		employeeDto.forEach(employees -> {
		});
		return "employee data Successfully";
	}

	@Override
	public List<String> getEmployee() {
		List<Employee> employeeList = employeeRepository.findBySalaryGreaterThan();
		if (employeeList.isEmpty()) {
					log.warn("thrown Exception");
			throw new UserDefinedException("No record Found");
		}
		List<String> employee1 = employeeList.stream().map(employee -> employee.getName()).collect(Collectors.toList());
		return employee1;
	}

	
	@Override
	public List<EmployeeSalaryDto> getEmployeesHikeData() {
		List<Employee> employeeList = employeeRepository.findBySalaryLessThan(20000);
		if (employeeList.isEmpty()) {
			log.warn("Exception thrown");
			throw new UserDefinedException("No records found");
		}
		employeeList.stream().forEach(employee -> {
			employee.setSalary(employee.getSalary() + 10000);
			employeeRepository.flush();
		});
		List<EmployeeSalaryDto> dtoList = employeeList.stream()
				.map(employee -> new EmployeeSalaryDto(employee.getSalary(), employee.getName()))
				.collect(Collectors.toList());
		return dtoList;
	}

	
	@Override
	public List<EmployeeResponseDto> getEmployeeNameAndDesignation() {
		List<Employee> employeeList = employeeRepository.findBySalaryLessThan(20000);
		if (employeeList.isEmpty()) {
			log.warn("Exception thrown");
			throw new UserDefinedException("No records found");
		}
		List<EmployeeResponseDto> dtoList = employeeList.stream()
				.map(employee -> new EmployeeResponseDto(employee.getName(), employee.getDesignation()))
				.collect(Collectors.toList());
		return dtoList;
	}

	
	

}

