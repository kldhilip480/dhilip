package com.example.demo.dto;
import java.util.List;


public class EmployeeDto {
	private String name;
	private String salary;
	private String designation;
	private int age;
	private int phoneNo;
	public String getName() {
		return name;
	}
	public void setId(String name) {
		this.name = name;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	public void add(List<EmployeeDto> employeeDto1) {
		// TODO Auto-generated method stub
		
	}

}


