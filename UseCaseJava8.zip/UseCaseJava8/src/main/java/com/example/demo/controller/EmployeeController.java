package com.example.demo.controller;

	import java.util.List;

	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.EmployeeDto;
import com.example.demo.dto.EmployeeResponseDto;
import com.example.demo.dto.EmployeeSalaryDto;
import com.example.demo.serviceimpl.EmployeeServiceImpl;

	

	@RestController
	public class EmployeeController {
		@Autowired
		EmployeeServiceImpl emploServiceImpl;
		private static final Logger log = LoggerFactory.getLogger(EmployeeController.class);

		@PostMapping("/users")
		public String saveUser(@RequestBody List<EmployeeDto> employeeDto){
			log.info("save Employee Data");
			
			return emploServiceImpl.saveEmployee(employeeDto);
		}
		@GetMapping("/users")
		public List<String> getAllEmployees(){
			log.info("we can get the employeees who are above 50000 salary");
			return emploServiceImpl.getEmployee();
		}
		@GetMapping("/users")
		public List<EmployeeSalaryDto> getAllEmployeesDatahike(){
			log.info("employeee salary hikes");
			return emploServiceImpl.getEmployeesHikeData();
		}
		@GetMapping("/salary")
		public List<EmployeeResponseDto> EmployessNamesAndDEsignation(){
			log.info("20000 salaries employee names and designations are");
			return emploServiceImpl.getEmployeeNameAndDesignation();
		}

	}



