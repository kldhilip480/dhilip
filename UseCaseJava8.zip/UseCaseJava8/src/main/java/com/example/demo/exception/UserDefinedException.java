package com.example.demo.exception;

public class UserDefinedException extends IllegalArgumentException{
	String str;

	public UserDefinedException(String str) {
		super();
		this.str = str;
	}

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}
	

}
