package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.EmployeeDto;
import com.example.demo.dto.EmployeeResponseDto;
import com.example.demo.dto.EmployeeSalaryDto;



public interface EmployeeService {
	public String saveEmployee(List<EmployeeDto> employeeDto);

	public List<String> getEmployee();

	public List<EmployeeSalaryDto> getEmployeesHikeData();

	public List<EmployeeResponseDto> getEmployeeNameAndDesignation();

}
